# my package
this library was created as an exemple of how to publish your own Python package.

# How to install 
...